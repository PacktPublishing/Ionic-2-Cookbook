import {Page} from 'ionic/ionic';

@Page({
  templateUrl: 'build/pages/page1/page1.html'
})
export class PageOne {
  constructor() {
  }
}
