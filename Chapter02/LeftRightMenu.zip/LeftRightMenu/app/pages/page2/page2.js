import {Page} from 'ionic/ionic';

@Page({
  templateUrl: 'build/pages/page2/page2.html'
})
export class PageTwo {
  constructor(){
  }
}
