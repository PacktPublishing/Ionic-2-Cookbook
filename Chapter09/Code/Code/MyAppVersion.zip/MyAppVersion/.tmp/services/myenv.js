import { Injectable } from '@angular/core';
import { AppVersion } from 'ionic-native';
export var MyEnv = (function () {
    function MyEnv() {
        this.appVersion = AppVersion;
    }
    MyEnv.prototype.getAppVersion = function () {
        return this.appVersion.getVersionCode();
    };
    MyEnv.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    MyEnv.ctorParameters = [];
    return MyEnv;
}());
//# sourceMappingURL=myenv.js.map