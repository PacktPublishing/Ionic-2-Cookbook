import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { MyEnv } from '../../services/myenv';
export var HomePage = (function () {
    function HomePage(navCtrl, myEnv) {
        this.navCtrl = navCtrl;
        this.myEnv = myEnv;
        this.myEnv = myEnv;
    }
    HomePage.prototype.getVersion = function () {
        var _this = this;
        console.log(this.myEnv.getAppVersion());
        this.myEnv.getAppVersion().then(function (data) { return _this.ver = data; });
    };
    HomePage.decorators = [
        { type: Component, args: [{
                    selector: 'page-home',
                    templateUrl: 'home.html'
                },] },
    ];
    /** @nocollapse */
    HomePage.ctorParameters = [
        { type: NavController, },
        { type: MyEnv, },
    ];
    return HomePage;
}());
//# sourceMappingURL=home.js.map